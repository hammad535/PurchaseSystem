
module PurchaseSystemConsole {
}