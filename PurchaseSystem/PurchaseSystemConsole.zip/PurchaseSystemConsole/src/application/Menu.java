package application;

import java.util.*;
public class Menu {

	public void menu() {
		System.out.println("------- Purchase Assistant ----------");
		System.out.println("1. Enter new supplier ");
		System.out.println("2. Enter new order ");
		System.out.println("3. View payment detail for orders");
		System.out.println("4. View delivery report \n");
		System.out.println("5. Exit \n");
	}
	
	// This method is used to display the menu options to the user and execute their choices accordingly.
	public void execute() {
		
		int choice=0;
		Scanner scan=new Scanner(System.in);
		
		while(true) { // loop runs infinitely until the user exits
			
			menu(); // displays the menu options to the user
			System.out.println("Enter your choice:"); 
			choice=scan.nextInt(); // takes user input for menu choice
			
			if(choice<0 || choice>5) { // checks if user input is a valid menu option
				System.err.print("Error! Invalid input"); // displays error message if invalid input is given
				
			}else {
				
				if(choice==1) { // if user chooses to add a supplier
					scan=new Scanner(System.in);
					System.out.println("Enter supplier name: ");
					String name=scan.nextLine(); // takes supplier name as input
					System.out.println("Enter supplier contact: ");
					String cont=scan.nextLine(); // takes supplier contact as input
					ArrayList<Order> orders=new ArrayList<>(); // creates a new ArrayList of Order objects to store the supplier's orders
					MainProg.suppliers.add(new Supplier(MainProg.suppliers.size()+1,name,cont,orders)); // adds the new supplier to the suppliers ArrayList
					System.out.println("Done! Supplier added."); // displays a message to inform user that the supplier has been added
					try {
						FileHandling.write(); // writes the updated data to a file
					}catch(Exception e) {
						System.out.println(e);
					}
					
				}else if(choice==2) { // if user chooses to place an order
					
					System.out.println("Here is a list of suppliers: ");
					for(int i=0;i<MainProg.suppliers.size();i++) { // displays a list of available suppliers to the user
						System.out.println(" ("+ i +"). "+ MainProg.suppliers.get(i).supplierName );
					}
					scan=new Scanner(System.in);
					int input=scan.nextInt(); // takes user input for the chosen supplier
					
					if(input < MainProg.suppliers.size() && input>-1) { // checks if the chosen supplier exists in the suppliers ArrayList
												
						System.out.println(" -- Initiate Order request --");
						
						Order newOrder = new Order(); // creates a new Order object to store the user's order
						int total = 0;
						while(true) { // loop runs until user exits
						
							scan=new Scanner(System.in);
							System.out.println("Enter item info:");
							String idesc=scan.nextLine(); // takes item description as input
							System.out.println("Enter item qty:");
							int qty=scan.nextInt(); // takes item quantity as input
							System.out.println("Enter item price:");
							int price = scan.nextInt(); // takes item price as input
							total+=price; // adds item price to total bill
							
							Items item = new Items(0,idesc,qty,price); // creates a new Items object to store item info
							newOrder.items.add(item); // adds the item to the user's order
							
							System.out.println(" Item Added! Press 0 to exit, any other key to continue adding items in your order.");
							String exit = scan.next(); // takes user input to exit the loop or continue adding items
							if(exit.equals("0"))
								break;
							
						}
						scan=new Scanner(System.in);
						System.out.println("Enter expected delivery date of this order:");
						String delivery = scan.nextLine(); // takes user input for the expected delivery date
						newOrder.deliveryDate = delivery;
						newOrder.totalBill = total;
						MainProg.suppliers.get(input).orders.add(newOrder);
						System.out.println(" Success! Your order has been placed. Total bill payable: "+total);
										
					}
					try {
						FileHandling.write();
					}catch(Exception e) {
						System.out.println(e);
					}
					
				}else if(choice==3) {
					
					// This line prints out a statement indicating that the following details are payment details
					System.out.println(" ---- Payment Details ---- ");

					// This for loop iterates through all the suppliers in the suppliers list
					for(int i=0;i<MainProg.suppliers.size();i++) {
						
						// This if statement checks if the supplier has any orders
						if( MainProg.suppliers.get(i).orders.size() != 0 ) {
						    
						    // This for loop iterates through all the orders made by the supplier
						    for(int j=0;j<MainProg.suppliers.get(i).orders.size();j++) {
						        
						        // This if statement checks if the order has not yet been delivered
						        if(MainProg.suppliers.get(i).orders.get(j).isDelivered == false) {
						            
						            // This line prints out the supplier ID, order ID and total bill of the order that has not been delivered
						            System.out.println(" Supplier Id: " + (i) + " Order Id: "+ (j) + " Total Bill: "+ MainProg.suppliers.get(i).orders.get(j).totalBill );
						            
						            // This line prints out a statement indicating that the following details are item details
						            System.out.println(" -- Item Details --");
						            
						            // This for loop iterates through all the items in the order
						            for(int k=0;k<MainProg.suppliers.get(i).orders.get(j).items.size();k++) {
						                
						                // This line prints out the item description and quantity of each item in the order
						                System.out.println(" "+k+". "+MainProg.suppliers.get(i).orders.get(j).items.get(k).itemDescription+ " | Qty: "+MainProg.suppliers.get(i).orders.get(j).items.get(k).qty);
						            }
						        }
						        
						    }
						    
						}

						
					}
					
					
					// Prompt the user to initiate payment for an order by entering 0
					System.out.println(" Do you want to initiate payment for any order? Press 0 to do so: ");

					// Read the user input
					String in = scan.next();

					// Check if the user input is equal to 0
					if(in.equals("0")) {
						// Prompt the user to enter the supplier ID and order ID
						System.out.println(" Enter Supplier Id:");
						int sid = scan.nextInt();
						System.out.println(" Enter Order Id:");
						int oid = scan.nextInt();

						// Check if the entered IDs are valid and the total bill is not 0
						if(sid < MainProg.suppliers.size()+1 && oid< MainProg.suppliers.get(sid).orders.size() && MainProg.suppliers.get(sid).orders.get(oid).totalBill!=0 ) {
						    
						    // Get the total bill amount
						    int total = MainProg.suppliers.get(sid).orders.get(oid).totalBill;
						    System.out.println(" Total Bill: " + total);
						    
						    // Prompt the user to enter the amount to be paid
						    System.out.println(" Enter amount you want to pay: ");
						    int pay = scan.nextInt();
						    
						    // Check if the amount entered is greater than the total bill
						    if(pay>total) {
						        System.out.println(" Payed: "+pay+ " | Extra: "+ (pay-total));
						        MainProg.suppliers.get(sid).orders.get(oid).totalBill = 0;
						    }
						    else {
						        // Update the remaining bill amount and display the payment details
						        MainProg.suppliers.get(sid).orders.get(oid).totalBill = total - pay;
						        System.out.println(" Payed: "+pay+ " | Remaining: "+ (total-pay));
						    }
						}

					}
					try {
						FileHandling.write();
					}catch(Exception e) {
						System.out.println(e);
					}
				}else if(choice==4) {
					
					System.out.println(" ---- Delivery Details ---- ");
					// This code loops through all suppliers and their orders to check for undelivered orders
					for(int i=0;i<MainProg.suppliers.size();i++) {
						
						if( MainProg.suppliers.get(i).orders.size() != 0 ) {
							
							for(int j=0;j<MainProg.suppliers.get(i).orders.size();j++) {
								
								if(MainProg.suppliers.get(i).orders.get(j).isDelivered == false) {
									System.out.println(" Supplier Id: " + (i) + " Order Id: "+ (j) + " | Deilvery Date: "+ MainProg.suppliers.get(i).orders.get(j).deliveryDate + " | isDelivered: " + MainProg.suppliers.get(i).orders.get(j).isDelivered );
									
									System.out.println(" -- Item Details --");
									
									for(int k=0;k<MainProg.suppliers.get(i).orders.get(j).items.size();k++) {
										System.out.println(" "+k+". "+MainProg.suppliers.get(i).orders.get(j).items.get(k).itemDescription+ " | Qty: "+MainProg.suppliers.get(i).orders.get(j).items.get(k).qty);
									}
								}
								
							}
							
						}
						
					}
					
				
					System.out.println(" Do you want to initiate delivery for any order? Press 0 to do so: ");
					String in = scan.next();
					if(in.equals("0")) {
						System.out.println(" Enter Supplier Id:");
						int sid = scan.nextInt();
						System.out.println(" Enter Order Id:");
						int oid = scan.nextInt();
						 
						if(sid < MainProg.suppliers.size()+1 && oid< MainProg.suppliers.get(sid).orders.size()) {
							String date = MainProg.suppliers.get(sid).orders.get(oid).deliveryDate;
							System.out.println(" Date: " + date);
							System.out.println(" Press 1: to mark it as delivered! ");
							int del = scan.nextInt();
							
							if(del == 1) {
								MainProg.suppliers.get(sid).orders.get(oid).isDelivered = true;
							}else {
								
								System.out.println(" Invalid choice! ");
							}
						}
					}
					
					
					try {
						FileHandling.write();
					}catch(Exception e) {
						System.out.println(e);
					}
				}else if(choice==5) {
					break;
				}
				
			}
			
		}
		
	}
	
	
}
