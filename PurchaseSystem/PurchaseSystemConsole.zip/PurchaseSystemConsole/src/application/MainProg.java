package application;
	
import java.util.*;

public class MainProg {
	static ArrayList<Supplier> suppliers=new ArrayList<>();	
	
	public static void main(String[] args) {
		try {
			FileHandling.read();
		}catch(Exception e) {
			System.out.println("Error Reading data: "+e);
		}
		
		Menu menu = new Menu();
		menu.execute();
	}
}
