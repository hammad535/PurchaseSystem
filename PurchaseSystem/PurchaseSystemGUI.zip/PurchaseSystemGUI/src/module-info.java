
module VirusSystem {
requires javafx.controls;
requires javafx.fxml;
requires javafx.graphics;
	
	opens Code to javafx.graphics, javafx.fxml;
}
