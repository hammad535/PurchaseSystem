package Code;

import java.io.Serializable;
import java.util.*;
@SuppressWarnings("serial")
public class Order implements Serializable{

	
	int orderId;
	String recievingDate;
	String deliveryDate;
	int totalBill;
	boolean isDelivered = false;  
	ArrayList<String> payments=new ArrayList<>();
	ArrayList<Items> items=new ArrayList<>();
	
	Order(){
		
	}
		
	
	public Order(int orderId, String creationDate, String deliveryDate, int totalBill, ArrayList<String> payments,
			ArrayList<Items> items) {
		this.orderId = orderId;
		this.recievingDate = creationDate;
		this.deliveryDate = deliveryDate;
		this.totalBill = totalBill;
		this.payments = payments;
		this.items = items;
	}


	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
	public int getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(int totalBill) {
		this.totalBill = totalBill;
	}
	public ArrayList<String> getPayments() {
		return payments;
	}
	public void setPayments(ArrayList<String> payments) {
		this.payments = payments;
	}


	public String getCreationDate() {
		return recievingDate;
	}


	public void setCreationDate(String creationDate) {
		this.recievingDate = creationDate;
	}


	public String getDeliveryDate() {
		return deliveryDate;
	}


	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}


	public ArrayList<Items> getItems() {
		return items;
	}


	public void setItems(ArrayList<Items> items) {
		this.items = items;
	}
	
	
	
	
	
}
