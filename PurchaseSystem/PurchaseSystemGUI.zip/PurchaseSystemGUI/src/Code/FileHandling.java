package Code;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class FileHandling {

	
	public static void write() {
		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("data.txt"))) {
            out.writeObject( MainProg.suppliers );
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}
	
	public static void read() {
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("data.txt"))) {
            ArrayList<Supplier> readList = (ArrayList<Supplier>) in.readObject();
            MainProg.suppliers = readList;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
		
	}
	
}
