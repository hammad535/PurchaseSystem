package Code;

import java.util.ArrayList;


import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;

public class Interface {

	public void load( AnchorPane root) {
		Button btnViewSuppliers = new Button();
		btnViewSuppliers.setLayoutX(184.0);
		btnViewSuppliers.setLayoutY(175.0);
		btnViewSuppliers.setMnemonicParsing(false);
		btnViewSuppliers.setPrefHeight(25.0);
		btnViewSuppliers.setPrefWidth(113.0);
		btnViewSuppliers.setStyle("-fx-background-color: green;");
		btnViewSuppliers.setText("View suppliers");
		btnViewSuppliers.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		btnViewSuppliers.setFont(new Font("System Bold", 12.0));
		root.getChildren().add(btnViewSuppliers);

		Label lblAddOrder = new Label();
		lblAddOrder.setLayoutX(247.0);
		lblAddOrder.setLayoutY(-3.0);
		lblAddOrder.setPrefHeight(34.0);
		lblAddOrder.setPrefWidth(219.0);
		lblAddOrder.setText("Add an Order");
		lblAddOrder.setTextFill(javafx.scene.paint.Color.web("#e1460e"));
		lblAddOrder.setFont(new Font("System Bold", 18.0));
		root.getChildren().add(lblAddOrder);

		TextArea txtAreaSample = new TextArea();
		txtAreaSample.setEditable(false);
		txtAreaSample.setLayoutX(12.0);
		txtAreaSample.setLayoutY(47.0);
		txtAreaSample.setPrefHeight(117.0);
		txtAreaSample.setPrefWidth(595.0);
		txtAreaSample.setStyle("-fx-background-color: grey;");
		txtAreaSample.setText("Sample text here");
		root.getChildren().add(txtAreaSample);

		Button btnAddOrder = new Button();
		btnAddOrder.setLayoutX(473.0);
		btnAddOrder.setLayoutY(175.0);
		btnAddOrder.setMnemonicParsing(false);
		btnAddOrder.setPrefHeight(25.0);
		btnAddOrder.setPrefWidth(113.0);
		btnAddOrder.setStyle("-fx-background-color: green;");
		btnAddOrder.setText("Add a Order");
		btnAddOrder.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		btnAddOrder.setFont(new Font("System Bold", 12.0));
		root.getChildren().add(btnAddOrder);

		Button addButton = new Button();
		addButton.setLayoutX(77.0);
		addButton.setLayoutY(175.0);
		addButton.setMnemonicParsing(false);
		addButton.setStyle("-fx-background-color: green;");
		addButton.setText("Add supplier");
		addButton.setTextFill(javafx.scene.paint.Color.valueOf("#eeebeb"));
		addButton.setFont(new Font("System Bold", 12.0));
		root.getChildren().add(addButton);

		Button viewOrdersButton = new Button();
		viewOrdersButton.setLayoutX(307.0);
		viewOrdersButton.setLayoutY(175.0);
		viewOrdersButton.setMnemonicParsing(false);
		viewOrdersButton.setPrefHeight(25.0);
		viewOrdersButton.setPrefWidth(146.0);
		viewOrdersButton.setStyle("-fx-background-color: green;");
		viewOrdersButton.setText("View Current Orders");
		viewOrdersButton.setTextFill(javafx.scene.paint.Color.valueOf("#eeebeb"));
		viewOrdersButton.setFont(new Font("System Bold", 12.0));
		root.getChildren().add(viewOrdersButton);

		Pane pane = new Pane();
		pane.setLayoutX(120.0);
		pane.setLayoutY(212.0);
		pane.setPrefHeight(255.0);
		pane.setPrefWidth(343.0);
		pane.setStyle("-fx-background-color: grey;");
		pane.setVisible(false);
		pane.toFront();



		Label label1 = new Label();
		label1.setLayoutX(20.0);
		label1.setLayoutY(14.0);
		label1.setPrefHeight(21.0);
		label1.setPrefWidth(146.0);
		label1.setText("Enter Supplier Id:");
		label1.setTextFill(javafx.scene.paint.Color.web("#eee7e7"));
		label1.setFont(new Font("System Bold", 15.0));
		pane.getChildren().add(label1);

		TextField supId = new TextField();
		supId.setLayoutX(228.0);
		supId.setLayoutY(12.0);
		supId.setPrefHeight(25.0);
		supId.setPrefWidth(96.0);
		supId.setStyle("-fx-background-color: yellow;");
		pane.getChildren().add(supId);

		Label label2 = new Label();
		label2.setLayoutX(20.0);
		label2.setLayoutY(59.0);
		label2.setPrefHeight(21.0);
		label2.setPrefWidth(192.0);
		label2.setText("Enter Item Description:");
		label2.setTextFill(javafx.scene.paint.Color.web("#eee7e7"));
		label2.setFont(new Font("System Bold", 15.0));
		pane.getChildren().add(label2);

		TextField itemDesc = new TextField();
		itemDesc.setLayoutX(228.0);
		itemDesc.setLayoutY(57.0);
		itemDesc.setPrefHeight(25.0);
		itemDesc.setPrefWidth(96.0);
		itemDesc.setStyle("-fx-background-color: yellow;");
		pane.getChildren().add(itemDesc);

		Label label3 = new Label();
		label3.setLayoutX(20.0);
		label3.setLayoutY(101.0);
		label3.setPrefHeight(21.0);
		label3.setPrefWidth(192.0);
		label3.setText("Enter Item Quantity:");
		label3.setTextFill(javafx.scene.paint.Color.web("#eee7e7"));
		label3.setFont(new Font("System Bold", 15.0));
		pane.getChildren().add(label3);

		Label label4 = new Label();
		label4.setLayoutX(20.0);
		label4.setLayoutY(140.0);
		label4.setPrefHeight(21.0);
		label4.setPrefWidth(192.0);
		label4.setText("Enter Item Price:");
		label4.setTextFill(javafx.scene.paint.Color.web("#eee7e7"));
		label4.setFont(new Font("System Bold", 15.0));
		pane.getChildren().add(label4);

		TextField itemQty = new TextField();
		itemQty.setLayoutX(228.0);
		itemQty.setLayoutY(99.0);
		itemQty.setPrefHeight(25.0);
		itemQty.setPrefWidth(96.0);
		itemQty.setStyle("-fx-background-color: yellow;");
		pane.getChildren().add(itemQty);


		TextField itemPrice = new TextField();
		itemPrice.setLayoutX(228.0);
		itemPrice.setLayoutY(138.0);
		itemPrice.setPrefHeight(25.0);
		itemPrice.setPrefWidth(96.0);
		itemPrice.setStyle("-fx-background-color: yellow;");

		Button addOrder = new Button();
		addOrder.setLayoutX(17.0);
		addOrder.setLayoutY(184.0);
		addOrder.setMnemonicParsing(false);
		addOrder.setPrefHeight(25.0);
		addOrder.setPrefWidth(308.0);
		addOrder.setStyle("-fx-background-color: green;");
		addOrder.setText("Add");
		addOrder.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		addOrder.setFont(Font.font("System Bold", 12.0));

		Button closeOrderPane = new Button();
		closeOrderPane.setLayoutX(17.0);
		closeOrderPane.setLayoutY(216.0);
		closeOrderPane.setMnemonicParsing(false);
		closeOrderPane.setPrefHeight(25.0);
		closeOrderPane.setPrefWidth(308.0);
		closeOrderPane.setStyle("-fx-background-color: green;");
		closeOrderPane.setText("Close");
		closeOrderPane.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		closeOrderPane.setFont(Font.font("System Bold", 12.0));

		pane.getChildren().addAll( itemPrice, addOrder, closeOrderPane);
		root.getChildren().add(pane);

		Pane pay = new Pane();
		pay.setLayoutX(27.0);
		pay.setLayoutY(262.0);
		pay.setPrefSize(237.0, 186.0);
		pay.setStyle("-fx-background-color: grey;");

		Label paymentLabel = new Label("Payment");
		paymentLabel.setLayoutX(81.0);
		paymentLabel.setLayoutY(-3.0);
		paymentLabel.setPrefSize(105.0, 34.0);
		paymentLabel.setTextFill(javafx.scene.paint.Color.web("#1e0702"));
		paymentLabel.setFont(new Font("System Bold", 18.0));

		//        TextField orderIdField = new TextField();
		//        orderIdField.setLayoutX(104.0);
		//        orderIdField.setLayoutY(45.0);
		//        orderIdField.setPrefSize(96.0, 25.0);
		//        orderIdField.setStyle("-fx-background-color: yellow;");
		//
		//        Label orderIdLabel = new Label("Order Id:");
		//        orderIdLabel.setLayoutX(20.0);
		//        orderIdLabel.setLayoutY(41.0);
		//        orderIdLabel.setPrefSize(96.0, 34.0);
		//        orderIdLabel.setTextFill(javafx.scene.paint.Color.web("#e8dfdd"));
		//        orderIdLabel.setFont(new Font(16.0));

		Button makePaymentButton = new Button("Make Payment");
		makePaymentButton.setLayoutX(10.0);
		makePaymentButton.setLayoutY(101.0);
		makePaymentButton.setPrefSize(219.0, 25.0);
		makePaymentButton.setStyle("-fx-background-color: green;");
		makePaymentButton.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		makePaymentButton.setFont(new Font("System Bold", 12.0));

		Button viewPaymentDetailButton = new Button("View Payment Detail");
		viewPaymentDetailButton.setLayoutX(10.0);
		viewPaymentDetailButton.setLayoutY(149.0);
		viewPaymentDetailButton.setPrefSize(219.0, 25.0);
		viewPaymentDetailButton.setStyle("-fx-background-color: green;");
		viewPaymentDetailButton.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		viewPaymentDetailButton.setFont(new Font("System Bold", 12.0));

		//  pay.getChildren().addAll(paymentLabel, orderIdField, orderIdLabel, makePaymentButton, viewPaymentDetailButton);
		pay.getChildren().addAll(paymentLabel, makePaymentButton, viewPaymentDetailButton);
		root.getChildren().add(pay);

		Pane pay1 = new Pane();
		pay1.setLayoutX(350.0);
		pay1.setLayoutY(262.0);
		pay1.setPrefWidth(237.0);
		pay1.setPrefHeight(186.0);
		pay1.setStyle("-fx-background-color: grey;");

		Label label = new Label("Delivery");
		label.setLayoutX(81.0);
		label.setLayoutY(-3.0);
		label.setPrefWidth(105.0);
		label.setPrefHeight(34.0);
		label.setTextFill(javafx.scene.paint.Color.web("#1e0702"));
		label.setFont(new Font("System Bold", 18.0));

		//        TextField textField = new TextField();
		//        textField.setLayoutX(104.0);
		//        textField.setLayoutY(45.0);
		//        textField.setPrefWidth(96.0);
		//        textField.setPrefHeight(25.0);
		//        textField.setStyle("-fx-background-color: yellow;");
		//
		//        Label label0 = new Label("Order Id:");
		//        label0.setLayoutX(20.0);
		//        label0.setLayoutY(41.0);
		//        label0.setPrefWidth(96.0);
		//        label0.setPrefHeight(34.0);
		//        label0.setTextFill(javafx.scene.paint.Color.web("#e8dfdd"));
		//        label0.setFont(Font.font(16.0));

		Button button = new Button("Mark as Delivered");
		button.setLayoutX(10.0);
		button.setLayoutY(101.0);
		button.setPrefWidth(219.0);
		button.setPrefHeight(25.0);
		button.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		button.setStyle("-fx-background-color: green;");
		button.setFont(Font.font("System Bold", 12.0));
		button.setMnemonicParsing(false);

		Button button0 = new Button("View Delivery Detail");
		button0.setLayoutX(10.0);
		button0.setLayoutY(149.0);
		button0.setPrefWidth(219.0);
		button0.setPrefHeight(25.0);
		button0.setTextFill(javafx.scene.paint.Color.web("#eeebeb"));
		button0.setStyle("-fx-background-color: green;");
		button0.setFont(Font.font("System Bold", 12.0));
		button0.setMnemonicParsing(false);

		// pay1.getChildren().addAll(label, textField, label0, button, button0);
		pay1.getChildren().addAll(label, button, button0);
		root.getChildren().addAll(pay1);

		TextArea textArea = new TextArea();
		textArea.setEditable(false);
		textArea.setLayoutX(29.0);
		textArea.setLayoutY(494.0);
		textArea.setPrefHeight(143.0);
		textArea.setPrefWidth(590.0);
		textArea.setStyle("-fx-background-color: grey;");
		textArea.setText("Sample text here");

		Label label11 = new Label();
		label11.setLayoutX(289.0);
		label11.setLayoutY(460.0);
		label11.setPrefHeight(34.0);
		label11.setPrefWidth(96.0);
		label11.setText("Details Area");
		label11.setTextFill(javafx.scene.paint.Color.web("#e1460e"));
		label11.setFont(new Font(16.0));

		root.getChildren().addAll(textArea, label11);


		// -------- Utility Functions ---------------





		// display add order pane
		btnAddOrder.setOnAction(a -> {
			pane.setVisible(true);
			pay.setVisible(false);
			pay1.setVisible(false);
		});

		//close add order pane
		closeOrderPane.setOnAction(a -> {
			pane.setVisible(false);
			pay.setVisible(true);
			pay1.setVisible(true);
		});

		// add supplier
		addButton.setOnAction(a -> {      	
			// Create a TextInputDialog object and set its content and header text
			TextInputDialog inputdialog = new TextInputDialog("Supplier Name");
			inputdialog.setContentText("Text: ");
			inputdialog.setHeaderText("Add a supplier");
			// Display the dialog and wait for user input
			inputdialog.showAndWait();
			// Get the text input from the dialog box
			String name = inputdialog.getEditor().getText();
			// Create another TextInputDialog object for supplier contact and get the input
			TextInputDialog inputdialog1 = new TextInputDialog("Supplier Contact");
			inputdialog1.setContentText("Text: ");
			inputdialog1.setHeaderText("Add a supplier");
			inputdialog1.showAndWait();
			String cont = inputdialog1.getEditor().getText();
			// Create an ArrayList object to store the orders of the supplier and add a new supplier to the suppliers list
			ArrayList<Order> orders=new ArrayList<>();
			MainProg.suppliers.add(new Supplier(MainProg.suppliers.size()+1,name,cont,orders));
			// Create an alert box to show that the supplier has been added
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Information Dialog");
			alert.setHeaderText("Supplier Added");
			alert.showAndWait();
			// Write to a file
			try {
				FileHandling.write();
			}catch(Exception e) {
				System.out.println(e);
			}
		});

		// view suppliers 
		btnViewSuppliers.setOnAction(a -> {
			displaySuppliers(txtAreaSample);
		});

		// add order
		addOrder.setOnAction(a -> {

			// Get the integer value of the text entered in supId and itemQty fields, and the item description and price from the corresponding text fields
			int sid = -1;
			try {
				 sid = Integer.parseInt(supId.getText());
			}catch(Exception e){
				System.out.println(e);
			}
			String desc = itemDesc.getText();
			int qty = -1;
			try {
				qty = Integer.parseInt(itemQty.getText());
			}catch(Exception e){
				System.out.println(e);
			}
			int price = -1;
			try {
				price = Integer.parseInt(itemPrice.getText());
			}catch(Exception e){
				System.out.println(e);
			}

			// Check if the sid is valid, then create a new order and add it to the supplier's order list
			if(sid < MainProg.suppliers.size() && sid>-1) {
				Order newOrder = new Order();
				int total = 0;

				// Create a new Items object and add it to the order items list, and update the total price
				Items item = new Items(0,desc,qty,price);
				newOrder.items.add(item);
				total+=price;

				// Create a TextInputDialog object to get the delivery date and add it to the new order, also set the total bill
				TextInputDialog inputdialog = new TextInputDialog("Delivery Date");
				inputdialog.setContentText("Text: ");
				inputdialog.setHeaderText("Date");
				inputdialog.showAndWait();
				String date = inputdialog.getEditor().getText();

				newOrder.deliveryDate=date;
				newOrder.totalBill=total;

				MainProg.suppliers.get(sid).orders.add(newOrder);

				// Create an alert box to show that the order has been added
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Information Dialog");
				alert.setHeaderText("Order Added");
				alert.showAndWait();

				// Write to a file
				try {
					FileHandling.write();
				} catch (Exception e) {
					System.out.println(e);
				}



			}else
			{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Information");
				alert.setHeaderText("Invalid Data recieved! No such supplier exists.");
				alert.showAndWait();
			}

		});

		//display Orders
		viewOrdersButton.setOnAction(a -> {
			displayOrders(txtAreaSample);
		});

		//view delivery detail
		button0.setOnAction(a -> {
			displayDeliveryInfo(textArea);
		});

		//view payment detail
		viewPaymentDetailButton.setOnAction(a -> {
			displayPaymentInfo(textArea);
		});

		//make payment
		makePaymentButton.setOnAction(a -> {

			// Displays an information alert about how to initiate payment for an order
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Payment Method Explanation");
			alert.setHeaderText("In order to initiate payment for an order, Please type ids carrefully by looking at records ");
			alert.showAndWait();

			// Takes input from user for supplier and order ids
			TextInputDialog inputdialog = new TextInputDialog("");
			inputdialog.setContentText("SupplierId: ");
			inputdialog.setHeaderText("Enter SupplierId");
			inputdialog.showAndWait();
			String id = inputdialog.getEditor().getText();
			int sid = -1;
			try {
				sid = Integer.parseInt(id);
			}catch(Exception e){
				System.out.println(e);
			}
			

			// Checks if the entered supplier id is valid
			if(sid < MainProg.suppliers.size() && sid>-1) {
				// Takes input from user for the order id
				TextInputDialog inputdialog1 = new TextInputDialog("");
				inputdialog1.setContentText("OrderId ");
				inputdialog1.setHeaderText("Enter OrderId");
				inputdialog1.showAndWait();
				String id1 = inputdialog1.getEditor().getText();
				int oid =-1;
				try {
					oid = Integer.parseInt(id1);
				}catch(Exception e){
					System.out.println(e);
				}
				
				if(sid < MainProg.suppliers.size()+1 && oid< MainProg.suppliers.get(sid).orders.size() && MainProg.suppliers.get(sid).orders.get(oid).totalBill!=0 ) {
					int total = MainProg.suppliers.get(sid).orders.get(oid).totalBill;
					TextInputDialog inputdialog11 = new TextInputDialog("");
					inputdialog11.setContentText("Enter : ");
					inputdialog11.setHeaderText("Total Payable Amount: "+total);
					inputdialog11.showAndWait();
					String amt = inputdialog11.getEditor().getText();
					int payment=0;
					try {
						 payment = Integer.parseInt(amt);
					}catch(Exception e){
						System.out.println(e);
					}
					

					// Check if the payment amount is greater than the total bill amount.
					if(payment>total) {
						Alert alert1 = new Alert(AlertType.INFORMATION);
						alert1.setTitle("Information Dialog");
						alert1.setHeaderText(" Payed: "+pay+ " | Extra: "+ (payment-total));
						alert1.showAndWait();
						MainProg.suppliers.get(sid).orders.get(oid).totalBill = 0;
					}else {
						Alert alert1 = new Alert(AlertType.INFORMATION);
						alert1.setTitle("Information Dialog");
						alert1.setHeaderText(" Payed: "+payment+ " | Remaining: "+ (total-payment));
						alert1.showAndWait();
						MainProg.suppliers.get(sid).orders.get(oid).totalBill = total - payment;
					}

					// Display the payment information in the text area and update the file.
					displayPaymentInfo(textArea);
					try {
						FileHandling.write();
					}catch(Exception e) {
						System.out.println(e);
					}
				}

			}



		});

		//make delivery
		button.setOnAction(a -> {

			// Create an alert to explain the delivery method
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Delivery Method Explanation");
			alert.setHeaderText("In order to initiate delivery for an order, Please type ids carefully by looking at records");
			alert.showAndWait();

			// Get the supplier ID from the user using a TextInputDialog
			TextInputDialog inputdialog = new TextInputDialog(" ");
			inputdialog.setContentText("SupplierId: ");
			inputdialog.setHeaderText("Enter SupplierId");
			inputdialog.showAndWait();
			String id = inputdialog.getEditor().getText();
			int sid =-1;
			try {
				sid = Integer.parseInt(id);
			}catch(Exception e){
				System.out.println(e);
			}
		

			// If the supplier ID is valid, proceed with getting the order ID from the user
			if(sid < MainProg.suppliers.size() && sid > -1) {
				TextInputDialog inputdialog1 = new TextInputDialog(" ");
				inputdialog1.setContentText("OrderId ");
				inputdialog1.setHeaderText("Enter OrderId");
				inputdialog1.showAndWait();
				String id1 = inputdialog1.getEditor().getText();
				int oid =-1;
				try {
					oid = Integer.parseInt(id1);
				}catch(Exception e){
					System.out.println(e);
				}
				

				// If the order ID is valid and the order hasn't been delivered yet, ask the user to confirm delivery
				if(sid < MainProg.suppliers.size() + 1 && oid < MainProg.suppliers.get(sid).orders.size() && MainProg.suppliers.get(sid).orders.get(oid).isDelivered == false) {
					TextInputDialog inputdialog11 = new TextInputDialog(" 1 ");
					inputdialog11.setHeaderText("Press 1 to mark as delivered, any other key to cancel");
					inputdialog11.showAndWait();
					String choice = inputdialog11.getEditor().getText();

					// If the user confirms delivery, mark the order as delivered and display a success message
					if(choice.equals("1")) {
						MainProg.suppliers.get(sid).orders.get(oid).isDelivered = true;
						Alert alert1 = new Alert(AlertType.INFORMATION);
						alert1.setTitle("Information Dialog");
						alert1.setHeaderText("Done! ");
						alert1.showAndWait();
						displayDeliveryInfo(textArea);
					}
					// If the user cancels, display a cancellation message
					else {
						Alert alert1 = new Alert(AlertType.INFORMATION);
						alert1.setTitle("Information Dialog");
						alert1.setHeaderText("Canceled!");
						alert1.showAndWait();
					}

					// Write the updated information to file
					try {
						FileHandling.write();
					} catch(Exception e) {
						System.out.println(e);
					}
				}
			}




		});

	}


	/*The displaySuppliers method displays a list of all the suppliers and their contact information.*/

	public void displaySuppliers(TextArea text) {

		text.setText("");
		text.appendText(" -- List of Suppliers --\n");
		for(int i=0;i<MainProg.suppliers.size();i++) {
			text.appendText(" Id: ("+ i +") "+ MainProg.suppliers.get(i).supplierName + " | Contact: "+ MainProg.suppliers.get(i).supplierContact );
		}

	}


	/*The displayOrders method displays a list of all the orders that have not yet been delivered.
	 *  It also includes information about the items in the order and their quantities.*/
	public void displayOrders(TextArea text) {
		// This code sets the text of a given text control to an empty string and appends a header message indicating that the following list shows information about suppliers.
		text.setText("");
		text.appendText(" -- List of Suppliers --\n");

		// This for loop iterates through all the suppliers in the MainProg singleton instance.
		for(int i=0;i<MainProg.suppliers.size();i++) {
			// The supplier name and contact details are added to the text control.
			text.appendText(" Id: ("+ i +") "+ MainProg.suppliers.get(i).supplierName + " | Contact: "+ MainProg.suppliers.get(i).supplierContact );

			// A new line and header message for the supplier's orders are added to the text control.
			text.appendText("\n -> Orders List: \n");

			// This for loop iterates through all the orders of the current supplier.
			for(int j=0;j<MainProg.suppliers.get(i).orders.size();j++) {

				// If the current order has not been delivered yet, the order details are added to the text control.
				if(MainProg.suppliers.get(i).orders.get(j).isDelivered == false) {
					text.appendText("\n Order Id: "+ (j) + " Total Bill: "+ MainProg.suppliers.get(i).orders.get(j).totalBill );

					// A new line and header message for the order's items are added to the text control.
					text.appendText("\n -- Item Details --");

					// This for loop iterates through all the items of the current order.
					for(int k=0;k<MainProg.suppliers.get(i).orders.get(j).items.size();k++) {

						// The description and quantity of the current item are added to the text control.
						text.appendText("\n "+k+". "+MainProg.suppliers.get(i).orders.get(j).items.get(k).itemDescription+ " | Qty: "+MainProg.suppliers.get(i).orders.get(j).items.get(k).qty);
					}
				}
			}
		}
	}


	/*The displayDeliveryInfo method displays a list of all the undelivered orders and their delivery details. 
	 * It also includes information about the items in the order and their quantities.*/
	public void displayDeliveryInfo(TextArea text) {
		text.setText("");
		text.appendText(" -- List of Suppliers --\n");
		for(int i=0;i<MainProg.suppliers.size();i++) {
			text.appendText(" Id: ("+ i +") "+ MainProg.suppliers.get(i).supplierName + " | Contact: "+ MainProg.suppliers.get(i).supplierContact );

			text.appendText("\n -> Orders List: ");

			for(int j=0;j<MainProg.suppliers.get(i).orders.size();j++) {
				if(MainProg.suppliers.get(i).orders.get(j).isDelivered == false) {
					text.appendText("\n Supplier Id: " + (i) + " Order Id: "+ (j) + " | Deilvery Date: "+ MainProg.suppliers.get(i).orders.get(j).deliveryDate + " | isDelivered: " + MainProg.suppliers.get(i).orders.get(j).isDelivered );

					text.appendText("\n -- Item Details --");

					for(int k=0;k<MainProg.suppliers.get(i).orders.get(j).items.size();k++) {
						text.appendText("\n"+k+". "+MainProg.suppliers.get(i).orders.get(j).items.get(k).itemDescription+ " | Qty: "+MainProg.suppliers.get(i).orders.get(j).items.get(k).qty);
					}
				}
			}

		}
	}

	/*The displayPaymentInfo method displays a list of all the undelivered orders and their total bill.
	 *  It also includes information about the items in the order and their quantities.*/
	public void displayPaymentInfo(TextArea text) {
		text.setText("");
		text.appendText(" -- List of Suppliers --\n");
		for(int i=0;i<MainProg.suppliers.size();i++) {
			text.appendText(" Id: ("+ i +") "+ MainProg.suppliers.get(i).supplierName + " | Contact: "+ MainProg.suppliers.get(i).supplierContact );

			text.appendText("\n -> Orders List: ");

			for(int j=0;j<MainProg.suppliers.get(i).orders.size();j++) {
				if(MainProg.suppliers.get(i).orders.get(j).isDelivered == false) {
					text.appendText("\n Supplier Id: " + (i) + " Order Id: "+ (j) + " Total Bill: "+ MainProg.suppliers.get(i).orders.get(j).totalBill );

					text.appendText("\n -- Item Details --");

					for(int k=0;k<MainProg.suppliers.get(i).orders.get(j).items.size();k++) {
						text.appendText("\n"+k+". "+MainProg.suppliers.get(i).orders.get(j).items.get(k).itemDescription+ " | Qty: "+MainProg.suppliers.get(i).orders.get(j).items.get(k).qty);
					}
				}
			}

		}
	}

}

