package Code;

import java.io.Serializable;
import java.util.*;

public class Supplier implements Serializable{

	int supplierId;
	String supplierName;
	String supplierContact;
	ArrayList<Order> orders=new ArrayList<>();
	
	Supplier(){
		
	}
	
		
	public Supplier(int supplierId, String supplierName, String supplierContact, ArrayList<Order> orders) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.supplierContact = supplierContact;
		this.orders = orders;
	}

	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierContact() {
		return supplierContact;
	}
	public void setSupplierContact(String supplierContact) {
		this.supplierContact = supplierContact;
	}
	public ArrayList<Order> getOrders() {
		return orders;
	}
	public void setOrders(ArrayList<Order> orders) {
		this.orders = orders;
	}
	
	
	
}
