package Code;

import java.io.Serializable;

public class Items implements Serializable{

	int itemId;
	String itemDescription;
	int qty;
	int price;
	
	Items(){}
	
	public Items(int itemId, String itemDescription, int qty, int price) {
		super();
		this.itemId = itemId;
		this.itemDescription = itemDescription;
		this.qty = qty;
		this.price = price;
	}
	
	
	
}
