
package Code;
import java.util.ArrayList;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainProg extends Application {

	static ArrayList<Supplier> suppliers=new ArrayList<>();	
	
    @Override
    public void start(Stage primaryStage) throws Exception {
        AnchorPane root = new AnchorPane();
        root.setPrefHeight(690.0);
        root.setPrefWidth(607.0);
        Interface inF=new Interface();
        inF.load(root);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
    	try {
			FileHandling.read();
		}catch(Exception e) {
			System.out.println("Error Reading data: "+e);
		}
    	launch(args);
    }
}